library(tidyverse)
#install.packages("adklakedata")
library(adklakedata)

#find what is in package
adklakedata::adk_data()

#what type of data from this function
?adk_data

#read in chemistry data
chemistry<-adk_data("chem")

#look at what information is in data
glimpse(chemistry)
#view(chemistry)
tail(chemistry, n=13)
summary(chemistry)
str(chemistry)

#filter lakes for Brooktrout
#Brooktrout <- chemistry %>% filter(lake.name == "Brooktrout") <- did this before
#or
Brooktrout <- filter(chemistry, lake.name == "Brooktrout")

#pipe
Brooktrout <- chemistry %>% 
  filter(lake.name == "Brooktrout")
#ctrl shift m is the short cut for pipe

#helper filter
temp <- filter(chemistry, str_detect(lake.name, "B")) %>% glimpse()
mistake <- temp %>% group_by(lake.name) %>% summarise(ph= mean(pH)) %>% glimpse()

#filter out specific lakes
emma <- c("Brooktrout", "Big Moose")
emma.filter <- chemistry %>% filter(lake.name %in% emma) %>% glimpse()

#example using select to selct colums interested in
btl_acid <- Brooktrout %>% 
  select(pH, SO4_minus2, NO3_minus, year)

#example with mutate function
btl_acid2 <- btl_acid %>% 
  mutate(odd_measure = SO4_minus2/pH) %>%
  glimpse()

#arrange in order from lowest to highest
btl_arranged <- btl_acid2 %>%
  arrange(odd_measure) %>% 
  glimpse()

#example using summary function to make summary of chemical info with group by
brooktrout_summary <- btl_acid2 %>% 
  group_by(year) %>% 
  summarise(odd_mean = mean(odd_measure), pH=mean(pH), so4=mean(SO4_minus2)) %>% 
  glimpse()



ggplot(brooktrout_summary, aes(x=year, y=odd_mean))+
  geom_point()

#==

ggplot(brooktrout_summary, aes(x=year))+
  geom_point(aes(y=odd_mean))

#########
ggplot(brooktrout_summary, aes(x=year, y=odd_mean))+
  geom_point()+
  geom_col(aes(y=pH,alpha=.1))

#in class example
#minimum oxygen per lake per year and plot a time series
oxygen <- adk_data("tempdo")

oxygen_per_lake <- oxygen %>% na.exclude() %>% group_by(lake.name, date) %>% 
  summarise(oxyMin = min(doobs))

ggplot(oxygen_per_lake, aes(date, oxyMin))+
  geom_line()+
  theme(legend.position = "none")+
  facet_wrap(~lake.name)



##########################################
oxygen$d <- as.Date(oxygen$date)
glimpse(oxygen)

min.oxy <- oxygen %>% 
  group_by(lake.name, d) %>% 
  summarise(min.oxy = min(doobs)) %>% 
  glimpse()

ggplot(min.oxy, aes(x = d, y = min.oxy, color = lake.name))+
  geom_line()+
  theme(legend.position = "none")+
  facet_wrap(~lake.name)

