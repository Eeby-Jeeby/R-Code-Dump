#Machine Learning BIOL6220
#Lecture21
#November 11, 2024
#Class topic: kNN
#Supervised machine learning

#libraries
library(janitor)
library(tidyverse)
library(lubridate)
library(class)

#load in the data
mushroom <- read.csv('mushroom_split.csv')
glimpse(mushroom)

#reassign categorical variables with numerical representations
#create mappings for each variable
class_map <- c("e" = 0, "p" = 1)
  #edible=e, poisonous=p
cap_shape_map <- c("b" = 1, "c" = 2, "x" = 3, "f" = 4, "s" = 5, "p" = 6, "o" = 7)  
  #bell=b, conical=c, convex=x, flat=f, sunken=s, spherical=p, others=o 
cap_surface_map <- c("i"=1, "g"=2, "y"=3, "s"=4, "h"=5, "l"=6, "k"=7,"t"=8,"w"=9, "e"=10)
  #fibrous=i, grooves=g, scaly=y, smooth=s, shiny=h, leathery=l, silky=k, sticky=t,wrinkled=w, fleshy=e
color_map <- c("n"=1, "b"=2, "g"=3, "r"=4, "p"=5, "u"=6, "e"=7,"w"=8,"y"=9, "l"=10, "o"=11, "k"=12, "f"=0)
  #brown=n, buff=b, gray=g, green=r, pink=p, purple=u, red=e, white=w, yellow=y, blue=l, orange=o, black=k, none=f
bruise_map <- c("f"=0, "t"=1)
  # bruises-or-bleeding=t,no=f
gill_attach_map <- c("a"=1, "x"=2, "d"=3, "e"=4, "s"=5, "p"=6, "f"=7,"?"= 'NA')
  #adnate=a, adnexed=x, decurrent=d, free=e,sinuate=s, pores=p, none=f, unknown=?
gill_spacing_map <- c("c"=1, "d"=2, "f"=3)
  #close=c, distant=d, none=f
stem_root_map <- c("b"=1, "s"=2, "c"=3, "u"=4, "e"=5, "z"=6, "r"=7)
  #bulbous=b, swollen=s, club=c, cup=u, equal=e, rhizomorphs=z, rooted=r
stem_surface_map <- c("i"=1, "g"=2, "y"=3, "s"=4, "h"=5, "l"=6, "k"=7,"t"=8,"w"=9, "e"=10, "f"=0)
  #see cap-surface + none=f
veil_type_map <- c("p"=1, "u"=2)
  #partial=p, universal=u
has_ring_map <- c("f"=0, "t"=1)
  #ring=t, none=f
ring_type_map <- c("c"=1, "e"=2, "r"=3, "g"=4, "l"=5, "p"=6, "s"=7,"z"=8,"y"=9, "m"=10, "f"=0, "?" = 'NA')
  #cobwebby=c, evanescent=e, flaring=r, grooved=g, large=l, pendant=p, sheathing=s, zone=z, scaly=y, movable=m, none=f, unknown=?
habitat_map <- c("g"=1, "l"=2, "m"=3, "p"=4, "h"=5, "u"=6, "w"=7,"d"=8)
  #grasses=g, leaves=l, meadows=m, paths=p, heaths=h, urban=u, waste=w, woods=d
season_map <- c("s"=1, "u"=2, "a"=3, "w"=4)
  #spring=s, summer=u, autumn=a, winter=w

mushroom2 <- mushroom %>%
mutate(
  class_ = recode(class, !!!class_map),
  cap_shape = recode(cap.shape, !!!cap_shape_map),
  cap_surface = recode(cap.surface, !!!cap_surface_map),
  cap_color = recode(cap.color, !!!color_map),
  bruise_bleed = recode(does.bruise.or.bleed, !!!bruise_map),
  gill_attachment = recode(gill.attachment, !!!gill_attach_map),
  gill_spacing = recode(gill.spacing, !!!gill_spacing_map),
  gill_color = recode(gill.color, !!!color_map),
  stem_root = recode(stem.root, !!!stem_root_map),
  stem_surface = recode(stem.surface, !!!stem_surface_map),
  stem_color = recode(stem.color, !!!color_map),
  veil_type = recode(veil.type, !!!veil_type_map),
  veil_color = recode(veil.color, !!!color_map),
  has_ring = recode(has.ring, !!!has_ring_map),
  ring_type = recode(ring.type, !!!ring_type_map),
  spore_print_color = recode(spore.print.color, !!!color_map),
  habitat_ = recode(habitat, !!!habitat_map),
  season_ = recode(season, !!!season_map)
)

mushroom.new <- mushroom2[,c(2,10,11,22:39)] 


#CODE ALONG START HERE____________________________
glimpse(mushroom.new)
mushroom.new$gill_attachment <- as.numeric(mushroom.new$gill_attachment)
mushroom.new$ring_type <- as.numeric(mushroom.new$ring_type)
glimpse(mushroom.new)

mushroom.new <- mushroom.new %>% 
  select(class_, everything()) %>% 
  clean_names()
glimpse(mushroom.new)

normalized.data <- function(x) {
  return((x - min(x))/ (max(x) - min(x)))
}

train_index = sample(1:nrow(mushroom.new), size = floor(0.7 * nrow(mushroom)),
                     replace = F)
training <- mushroom.new[train_index, c(1:21)]
testing <- mushroom.new[-train_index, c(1:21)]

write.csv(mushroom.new, "mushroom2.csv", row.names = FALSE)

# Feature Scaling 
train_scale <- scale(training[,2:21]) 
test_scale <- scale(testing[,2:21]) 


head(train_scale)
head(test_scale)

m3 <- knncatimpute(as.matrix(mushroom.new))

classifier_knn <- knn(train = train_scale, 
                      test = test_scale, 
                      cl = training$class, 
                      k = 1) 
classifier_knn 

A <- read_csv("mushroom3(2).csv") 
str(A)
B <- mutate(A, across(where(is.numeric), round, 0))
B$class <- A$class
B <- B[-1]
B$cap_diameter <- A$cap_diameter
B$stem_height <- A$stem_height
B$stem_width <- A$stem_width
B$class <- A$class
write.csv(B, "mushroom_generated.csv", row.names = FALSE)
