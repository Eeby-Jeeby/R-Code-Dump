library(corrplot)
library(adklakedata)
library(tidyverse)

library(FactoMineR)#need this
library(factoextra)#need this
library(FactoInvestigate)#optional
library(ggfortify)#optional

chem<- adk_data('chem')

chem<- chem %>% filter(lake.name=="Jockeybush")

chem2<-na.omit(chem) %>% glimpse()

attach(chem2) #takes everything in chem2 and makes it global
chem3 <- chem2 %>% select(lake.name, date, NO3_minus, CL, ANC.ueq.L, DOC, Calcium, Mg, AL_IM.ug.L, pH, conduct.uS.cm)
#make sure you detach, cause otherwise everything will call the variables from chem2
detach(chem2)

?attach

glimpse(chem3)

chem3$date <- ymd(chem3$date)

#explore correlations
cor.mat <- cor(chem3[,3:11]) #skip first couple of columns cause lake name and date
corrplot(cor.mat, type="lower")

?ggpairs

?PCA
chem.pca <- PCA(chem3[,3:11], scale=T, graph=F)

chem.pca$eig #if the first 2 components does not explain most of the variance, pca is not the right choice

plot(chem.pca, label = "none")
#the plot is useless -> 57% vairance on dim 1 line? what does that mean?

#eighenvalues

#cos3 quality of representation of columns and rows
chem.pca$var$cor #strongest correlates on dim1 is no3, al, calciumn, conduct, dim2 etc
chem.pca$var$contrib #same info, diff units

#scree plot
fviz_eig(chem.pca)

dev.off()

#CORRELATION CIRCLE
fviz_pca_var(chem.pca, axes=c(1,2), repel = T)

?fviz_pca_var
#better description of the axis
chem.desc <- dimdesc(chem.pca,
                     axes = 1:5,
                     proba = 0.05)
chem.desc
chem.desc$Dim.1
chem.desc$Dim.2


#individuals mapped to pca space
fviz_pca_ind(chem.pca,
             col.ind = chem2$year,
             label = "none")
fviz_pca_var(chem.pca)
#ph and anc have become less acidic and more towards the mg and calcium etc
#there has been a shift over time

#biplot -> confusing with combined data
fviz_pca_biplot(chem.pca,
                col.ind = chem2$year,
                label = "var",
                repel = T)


#in class
#in kb-iter