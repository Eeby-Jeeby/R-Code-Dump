setwd("C:/Users/Evelyn/Desktop/Machine Learning For EnvSci")
library(MASS) #has a select that will overlay dyplr
library(vegan)
library(Rtsne)

#need to load
library(corrplot)
library(adklakedata)
library(tidyverse)
library(FactoMineR)#need this
library(factoextra)#need this
library(FactoInvestigate)#optional
library(ggfortify)#optional
# 
soil <- read_csv("mcmlter-soil-et-20220318.csv")
glimpse(soil)
soil2 <- soil %>% select(elevation, position, date_time, soil_water_content,
                         total_rotifers, total_tardigrades, tn, soc, sic, nh4_n, no3_n, valley_code) %>% 
  glimpse()
soil3 <- soil2[complete.cases(soil2), ]
soil3$date_time <- mdy_hm(soil3$date_time)
#PCA
#####
soil.cov <- cov(soil3[,4:11])
soil.cov
soil.cor <- cor(soil3[,4:11])
soil.cor
scree(soil.cor)
fa.parallel(soil.cor, n.obs = 54)
vss(soil.cov, n.obs = 54)


soilfactor<-fa(soil3[,4:11],nfactors=2,
               rotate = "varimax")

summary(soilfactor)

#plots
factor.plot(soilfactor)
fa.diagram(soilfactor)

soil.pca <- PCA(soil3[,4:11], scale=T, graph=F)
soil.pca$eig
plot(soil.pca)
cor.mat <- cor(soil3[,4:14]) #skip first couple of columns cause lake name and date
corrplot(cor.mat, type="lower")

#scree plot
fviz_eig(soil.pca)

dev.off()

#CORRELATION CIRCLE
fviz_pca_var(soil.pca, axes=c(1,2), repel = T)

?fviz_pca_var
#better description of the axis
chem.desc <- dimdesc(chem.pca,
                     axes = 1:5,
                     proba = 0.05)
chem.desc
chem.desc$Dim.1
chem.desc$Dim.2


#individuals mapped to pca space
fviz_pca_ind(chem.pca,
             col.ind = chem2$year,
             label = "none")
fviz_pca_var(chem.pca)
#ph and anc have become less acidic and more towards the mg and calcium etc
#there has been a shift over time

#biplot -> confusing with combined data
fviz_pca_biplot(chem.pca,
                col.ind = chem2$year,
                label = "var",
                repel = T)
#MDS
#####

soil_dist <- dist(soil3[,4:7], method = "maximum")
soil_dist

soil_mds <- cmdscale(soil_dist, k=2)
soil_mds

soil_mds2 <- data.frame(soil_mds)
soil_mds3 <- cbind(soil_mds2, valley=soil3$valley_code, date=soil3$date_time)
glimpse(soil_mds3)

ggplot(soil_mds3, aes(X1,X2, color=factor(date)))+
  geom_point()+
  facet_wrap(~valley)

ggplot(soil_mds3, aes(X1,X2, color=valley))+
  geom_text(aes(label = valley))


#NMDS
#####
nmds.soil <- metaMDS(soil3[,4:11],
                       k=2,
                       trymax = 100,
                       autotransform = F,
                       distance="bray")
nmds.soil$stress
plot(nmds.soil)

species<-nmds.soil$species
points<-nmds.soil$points

nmds.plot <- data.frame(cbind(points, soil3$elevation))

glimpse(nmds.plot)
nmds.plot$MDS1 <- as.numeric(nmds.plot$MDS1)
nmds.plot$MDS2 <- as.numeric(nmds.plot$MDS2)

ggplot(species, aes(MDS1, MDS2))+
  geom_text(aes(label=row.names(species)))+
  geom_point(data = nmds.plot, aes(MDS1, MDS2, color = soil3$elevation))
