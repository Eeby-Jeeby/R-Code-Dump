library(tidyverse)
library(GGally)

library(psych)
library(GPArotation)
library(heplots)
# Growth of Apple Trees from Different Root Stocks
# 
# In a classic experiment carried out from 1918 to 1934, growth of apple 
# trees of six different rootstocks were compared on four measures of size.
# 
# A data frame with 48 observations on the following 5 variables.
# 
# a factor with levels 1 2 3 4 5 6
# girth4 - a numeric vector: trunk girth at 4 years (mm x 100)
# ext4 - a numeric vector: extension growth at 4 years (m)
# girth15 - a numeric vector: trunk girth at 15 years (mm x 100)
# weight15 - a numeric vector: weight of tree above ground at 15 years (lb x 1000)


root<-data("RootStock")
glimpse(RootStock)
# 



tidyroot<- RootStock %>% 
  gather('measure', 'growth', -rootstock)
# 


str(tidyroot)
# 



ggplot(tidyroot, aes(growth, fill=measure))+
  geom_density(alpha=.1)
# 




ggpairs(RootStock)
# 


root.cor<-cor(RootStock[,2:5])
root.cor
root.cov <- cov(RootStock[,2:5])
root.cov
# 

#have not loaded corrplot, but can still use it
corrplot::corrplot(root.cor)

#bartlet test-compare correlation matrix to non correlated data
cortest.bartlett(root.cor, n=48)

KMO(root.cor)
#


#how many factors, values greater than 1
root.eig <- eigen(root.cor)
root.eig

#where is the elbow -> visual presentation of variance
scree(root.cor)

#parallel analysis -> creates simulated data and plots it against your actual data
fa.parallel(root.cor, n.obs = 48)

#how many factors
vss(root.cov, n.obs = 48)
?vss

#for ease, select only data and perform factor analysis
root.good<- RootStock[,2:5]
rootfactor<-fa(root.good,nfactors=2,
               rotate = "varimax")

summary(rootfactor)

#plots
factor.plot(rootfactor)
fa.diagram(rootfactor)

rootscore<-rootfactor$scores
glimpse(rootscore)

rootclust <- cbind(RootStock, rootscore)
glimpse(rootclust)

#how can we plot everything we want?
ggplot(rootclust, aes(MR1,MR2, color=rootstock))+
  geom_point(size=6)


library(adklakedata)

chem<-adk_data("chem") %>% 
  glimpse()
chem2<- chem %>% 
  select(conduct.uS.cm, pH,AL_IM.ug.L,
         NH4_plus,Sodium,Calcium,DOC,ANC.ueq.L,
         SO4_minus2, NO3_minus )
cor(chem2,use="complete.obs")

chemcor<-cor(chem2, use="na.or.complete")
eigen(chemcor)
scree(chemcor)
vss(chemcor, rotate="varimax", fm="mle")

chemfa<-fa(chem2, nfactors=3, rotate="varimax", fm="mle")
summary(chemfa)


fa.diagram(chemfa) #three basic things in the data; darkness, charge, and acidity
#we can then re apply the factor analysis to the original data

chemclust <- cbind(chem, chemfa$scores)
str(chemclust)

chemclust<-chemclust %>% 
  filter(lake.name=="Brooktrout")
chemclust$year <- as.factor(chemclust$year)

ggplot(chemclust, aes(ML1, ML2, col=year))+
  geom_point()
ggplot(chemclust, aes(ML1, ML3, col=year))+
  geom_point()
ggplot(chemclust, aes(ML2, ML2, col=year))+
  geom_point()
