library(janitor)
library(tidyverse)
library(lubridate)
library(factoextra)
library(cluster)
library(dendextend)
library(ggthemes)

clam.morph <- read.csv("clam_morph.csv")
clam.morph <- clean_names(clam.morph)
glimpse(clam.morph)

clam.morph$sample_date <- mdy(clam.morph$sample_date)
clam.use <- clam.morph[,4:9]
clam.scale <- scale(clam.use)

#perform clustering
?dist

#distance matrix
clam.dist <- dist(clam.scale)
#then cluster
clam.clust <- hclust(clam.dist, method = "ward.D2")

plot(clam.clust)

#prettier plot
clam.dend <- as.dendrogram(clam.clust)
clam.colored <- color_branches(clam.dend, h = 25) # k = # of clusters,
#                                                   h = cuts by height
plot(clam.colored)

#identify clusters - cut the tree at 5 clusters
clam.clusters <- cutree(clam.clust, k = 5)
clam.morph$clusters <- factor(clam.clusters)

table(clam.morph$site, clam.morph$clusters)
glimpse(clam.morph)

#plot again
ggplot(clam.morph, aes(site, fill = clusters)) +
  geom_bar() +
  facet_grid(site ~ month(sample_date)) +
  theme_fivethirtyeight()
# almost no green on the graphs. cluster 5 only exists in the fifth month (may).
#cluster 4 becomes dominant as the season progresses

#why are there different clusters??
#data frame with only info we care about - location, date, cluster, and use
clam.pretty <- data.frame(clam.morph[,1:3],
                          clam.clusters,
                          clam.use)
glimpse(clam.pretty)

#wide -> long
clam.spread <- gather(clam.pretty,
                      analyte,
                      amount,
                      -id, -site, -sample_date, -clam.clusters)

glimpse(clam.spread)

ggplot(clam.spread, aes(factor(clam.clusters), amount)) +
  geom_boxplot() +
  facet_wrap(~analyte, scales = "free") +
  theme_economist()

#compare some methods
clam.tangle <- clam.morph %>% 
  filter(month(sample_date) == 5) %>% 
  select(4:9)

tang.dist <- dist(clam.tangle, method = "manhattan")

tang.ward <- as.dendrogram(hclust(tang.dist, method = "ward.D2"))

tang.single <- as.dendrogram(hclust(tang.dist, method = "single"))

tang.complete <- as.dendrogram(hclst(tang.dist, method = "complete"))

plot(tang.ward)

plot(tang.single)

plot(tang.complete)
#tanglegram
tanglegram(tang.ward, tang.complete)

dadjoke::dadjoke()

#on own example - pokemon
poke <- read.csv("pokemon.csv") %>% 
  clean_names()

glimpse(poke)

poke.use <- poke %>% 
  select(attack, defense, height_m, hp, sp_attack, sp_defense, speed,
         weight_kg, generation)

poke.dist <- dist(poke.use)

poke.clust <- hclust(poke.dist, method = "ward.D2")

plot(poke.clust)

poke.dend <- as.dendrogram(poke.clust)

poke.color <- color_branches(poke.dend, k = 8)

plot(poke.color)

poke.clusters <- cutree(poke.clust, k = 8)

poke$clusters <- factor(poke.clusters)

glimpse(poke)

ggplot(poke, aes(pokedex_number, fill = clusters)) +
  geom_bar() +
  facet_wrap(~generation, scales = "free") +
  theme_fivethirtyeight()
