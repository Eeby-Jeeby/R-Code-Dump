library(tidyverse)
library(lubridate)
#install.packages("gganimate")
library(gganimate)
#install.packages("gifski")
library(gifski)

sontek <- read.csv("beams.csv")

glimpse(sontek)

sontek.tame <- sontek %>% 
  select(Sample.Time, Sample.Number, contains('vEl')) %>% 
  glimpse()

#wide to long
sontek.tidyl <- sontek.tame %>% 
  gather(cell, velocity, -Sample.Time, -Sample.Number) %>% 
  glimpse()

#split by periods
sontek.tidy2 <- sontek.tidyl %>% 
  separate(cell, c("cell", "2", "3", "4", "5", "beam","7", "8","9"), 
           sep = "\\.", extra = "merge")


#select and filter
sontek.tidy3 <- sontek.tidy2 %>% 
  select(Sample.Time, Sample.Number, cell, beam, velocity) %>% 
  filter(beam == 1| beam == 2) %>% 
  glimpse()

sontek.tidy <- sontek.tidy3
sontek.tidy$depth <- parse_number(sontek.tidy$cell)
sontek.tidy$velocity <- parse_number(sontek.tidy$velocity)
sontek.tidy$beam <- parse_guess(sontek.tidy$beam)

glimpse(sontek.tidy)


#heatmap
ggplot(sontek.tidy, aes(Sample.Number, depth))+
  geom_tile(aes(fill = velocity))+
  theme_bw()+
  #scale_fill_gradientn(colours = c("red", "white", "green"),
   #                    values = c(-1, 0.1, 1))+
  facet_wrap(~beam)


ggplot(sontek.tidy, aes(velocity, depth, size = 1, color=beam))+
  geom_point()+
  theme_bw()+
  geom_vline(xintercept=0, color="red", size=2)+
  facet_wrap(~beam)+
  shadow_wake(wake_length = 0.1, alpha = FALSE)+
  transition_time(sontek.tidy$Sample.Number)


#in class assignment
# read in tea island data and make a graph with dissolved oxygen, temp, and conductivity on x axis and depth on Y
#with facet wrap

##clean up tea island data##
library(anytime)
teaisland <- read_csv("teaisland.csv", skip = 18) %>% glimpse()

#get date into right format and remove the original date time
teaisland_corrected <- teaisland %>% 
  mutate(Date = anytime(teaisland$`Date Time`)) %>% 
  select(-c(`Date Time`)) %>% 
  glimpse()

teaisland$surface<-teaisland$`Temperature (°F) (749249)`
glimpse(teaisland)

teaisland$conductivity <- teaisland$`Actual Conductivity (µS/cm) (743371)`
glimpse(teaisland)

#select for depth and temperature and give vars better names
teaisland_depthtemp <- teaisland_corrected %>% 
  select(Depth = `Depth (m) (720372)`,
         Temperature = `Temperature (°F) (737866)`,
         Conductivity = `Specific Conductivity (µS/cm) (743371)`,
         Oxygen = `RDO Concentration (mg/L) (741503)`,
         Date = Date) %>% 
  glimpse()

teaisland_depthtemp_l <- teaisland_depthtemp %>% 
  gather("measure", "value", -Date, -Depth)

ggplot(teaisland_depthtemp_l, aes(value, Depth, color=measure))+
  geom_point()+
  scale_y_reverse()+
  facet_wrap(~measure, scales = "free")

