library(MASS) #has a select that will overlay dyplr
library(vegan)
library(Rtsne)

#need to load
library(corrplot)
library(adklakedata)
library(tidyverse)
library(FactoMineR)#need this
library(factoextra)#need this
library(FactoInvestigate)#optional
library(ggfortify)#optional

brain <- read.csv("GSE28379 - GSE28379_series_matrix.csv")
gene <- read.csv("gene.csv")

glimpse(brain)
glimpse(gene)

brain_gene <- merge(x = brain, y = gene, by.x = "ID_REF", by.y = "ID") %>% 
  glimpse()

brain_gene_clean <- brain_gene %>% 
  select(ID_REF, GSM701542, GSM701543, GSM701544, GSM701545, no.mutation,
         mutation, log.2.fold.change, fold.change, Gene.symbol, Gene.title) %>% 
  na.omit() %>% 
  glimpse()

brain_gene_clean_2 <- brain_gene_clean %>% 
  select(Gene.symbol, GSM701542, GSM701543, GSM701544, GSM701545, no.mutation,
         mutation, log.2.fold.change)

#brain_gene_clean_2 <- data.frame(t(brain_gene_clean_2[-1]))
#colnames(brain_gene_clean_2) <- brain_gene_clean[,10]

brain_pca <- PCA(brain_gene_clean_2[,2:7], scale = T, graph = F)
brain_pca$eig
plot(brain_pca, label = "none")
brain_pca$var$cor



#scree plot
fviz_eig(brain_pca)

dev.off()

#CORRELATION CIRCLE
fviz_pca_var(brain_pca, axes=c(1,2), repel = T)

?fviz_pca_var
#better description of the axis
brain_esc <- dimdesc(brain_pca,
                     axes = 1:5,
                     proba = 0.05)
brain_esc
brain_esc$Dim.1
brain_esc$Dim.2


#individuals mapped to pca space
fviz_pca_ind(brain_pca,
             col.ind = brain_gene_clean_2$Gene.symbol,
             label = "none")
fviz_pca_var(brain_pca)
#ph and anc have become less acidic and more towards the mg and calcium etc
#there has been a shift over time

#biplot -> confusing with combined data
fviz_pca_biplot(brain_pca,
                col.ind = brain_gene_clean_2$Gene.symbol,
                label = "var",
                repel = T)

