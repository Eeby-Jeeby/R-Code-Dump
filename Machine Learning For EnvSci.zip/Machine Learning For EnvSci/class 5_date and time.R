library(tidyverse)
library(anytime)
library(janitor)
library(lubridate)

swamp<-read_csv('beams.csv') %>% 
  clean_names() %>% glimpse()

#swamp.date <- swamp$sample_time
swamp.date <- swamp %>% 
  select(sample_time) %>%  #same thing as above
  glimpse()

swamp.date$asdate <- as.Date(swamp$sample_time)
glimpse(swamp.date)
?as.POSIXct

swamp.date$posix<-as.POSIXct(swamp$sample_time,
                             tz="EST",
                             format = "%m/%d/%Y %H:%M")
glimpse(swamp.date)

?anytime

swamp.date$any <- anytime(swamp$sample_time)
glimpse(swamp.date)

?mdy
#the tidyverse way
swamp.date$mdy <- mdy_hm(swamp$sample_time, tz="EST")
glimpse(swamp.date)

#ok thats right, lets rewrite the sample time
glimpse(swamp)
swamp$sample_time<- mdy_hm(swamp$sample_time, tz="EST")
glimpse(swamp)

?separate
#pull pieces apart with separate
date.time <- separate(swamp, sample_time, sep=" ", into=c("date1", "time"))
year.month.day <- separate(date.time, date1, sep="-", into=c("year","month","day"))

#pieces<-swamp$sample_time
am(swamp$sample_time)
#day(pieces)
day(swamp$sample_time)
yday(swamp$sample_time)
wday(swamp$sample_time, label=T)

#round time
?round_date
swamp$round_hour<-round_date(swamp$sample_time, "hour")

ceiling_date(swamp$sample_time, "10 minutes")
?floor_date
floor_date(swamp$sample_time, "1 day")



#plots
library(dplyr)
swamp.long <- swamp %>% 
  select(dplyr::contains("vel"), sample_time) %>% 
            #key      value
  gather("velocity", "speed", -sample_time) %>% 
  glimpse()
swamp.long$speed <- as.numeric(swamp.long$speed)
swamp.long2 <- swamp.long %>% 
  na.omit()

swamp.summary <- swamp.long2 %>% 
  group_by(sample_time) %>% 
  summarise(mean=mean(speed)) %>% 
  glimpse()

ggplot(swamp.summary, aes(sample_time, mean))+
  geom_point()+
  geom_smooth()


#what day of the week did the tea island data get collected?
#round the data to every minute and average the temperature

teaisland <- read_csv("teaisland.csv", skip = 18) %>% glimpse()

#get date into right format and remove the original date time
teaisland_corrected <- teaisland %>% 
  mutate(Date = anytime(teaisland$`Date Time`),
         Surface = `Temperature (°F) (749249)`) %>% 
  select(-c(`Date Time`)) %>% 
  glimpse()

teaisland_selected <- teaisland_corrected %>% 
  select(Date, Surface) %>%
  mutate(round.minute = round_date(Date, "2 minutes"))

teaisland_selected2 <- teaisland_selected %>% 
  group_by(round.minute) %>% 
  summarise(mean=mean(Surface)) %>% glimpse()

wday(teaisland_selected$Date, label=TRUE)
ggplot(teaisland_selected2, aes(round.minute, mean))+
  geom_point()+
  geom_smooth()+
  theme_classic()+
  ylab("Surface Temperature (°F)")+
  xlab("Time (Minutes)")
