#need to install and load
library(MASS) #has a select that will overlay dyplr
library(vegan)
library(Rtsne)

#need to load
library(corrplot)
library(adklakedata)
library(tidyverse)
library(FactoMineR)#need this
library(factoextra)#need this
library(FactoInvestigate)#optional
library(ggfortify)#optional

interesting.lakes <- c("Big Moose", "G", "Jockeybush", "Indian")

chem<-adk_data("chem")

chem2<- chem %>% 
  filter(year == 2011 & lake.name %in% interesting.lakes) %>% 
  na.omit()

glimpse(chem2)

chem3<-chem2[,c(6:16)]
?dist

chem_dist <- dist(chem3, method = "maximum")
chem_dist

chem_mds <- cmdscale(chem_dist, k=2)
chem_mds

chem_mds2 <- data.frame(chem_mds)
chem_mds3 <- cbind(chem_mds2, lake=chem2$lake.name, date=chem2$month)

glimpse(chem_mds3)
ggplot(chem_mds3, aes(X1,X2, color=factor(date)))+
  geom_point()+
  facet_wrap(~lake)

ggplot(chem_mds3, aes(X1,X2, color=lake))+
  geom_text(aes(label = lake))

#nmds-vegan
c<-adk_data("crust")
cr<-c %>% 
  filter(lake.name %in% interesting.lakes)

cru<-cr %>% 
  group_by(lake.name, date, Genus) %>% 
  summarise(org=sum(org.l))

glimpse(cru)
##
library(beepr)
beep
##
crus<-cru %>% 
  spread(Genus, org) %>% 
  glimpse()

#remove columns with 0 sum
crust <- crus[,3:21] %>% 
  select_if(colSums(.)!= 0) #. means everything

nmds.crusty <- metaMDS(crust,
                       k=2,
                       trymax = 100,
                       autotransform = F,
                       distance="bray")

nmds.crusty$stress

plot(nmds.crusty)

#red is species,

#look at the nmds file
species<-nmds.crusty$species
points<-nmds.crusty$points

nmds.plot <- data.frame(cbind(points, crus$lake.name))

glimpse(nmds.plot)
nmds.plot$MDS1 <- as.numeric(nmds.plot$MDS1)
nmds.plot$MDS2 <- as.numeric(nmds.plot$MDS2)

ggplot(species, aes(MDS1, MDS2))+
  geom_text(aes(label=row.names(species)))+
  geom_point(data = nmds.plot, aes(MDS1, MDS2, color = crus$lake.name))

p<-adk_data("phyto")
ph<-p %>% 
  filter(lake.name %in% interesting.lakes) %>% 
  filter(Phylum == "Miozoa") %>% 
  group_by(lake.name) %>% 
  count(Genus) %>% 
  glimpse()

phy<-ph %>% 
  spread(lake.name, n) %>% 
  replace(is.na(.), 0) %>% 
  glimpse()

phyt <- data.frame(phy) %>% glimpse()

phytp<- phyt %>% 
  column_to_rownames("Genus") %>% 
  glimpse()

phytp.ca <- CA(phytp)
  
fviz_ca_biplot(phytp.ca,
               map = "symbiplot",
               arrow=c(TRUE, FALSE),
               repel = TRUE)

