library(tidyverse)
library(lubridate)
library(FactoMineR)
library(adklakedata)
library(factoextra)

# might need to download these
library(gridExtra)
library(NbClust)
library(cluster)

?faithful
old <- faithful
glimpse(old)

ggplot(old, aes(eruptions, waiting))+
  geom_point(size=4)
#two distinct clusters

NbClust(old, method = "kmeans")

old.k <- kmeans(old, centers = 2) #majority says 2
old.k$size

cluster<-factor(old.k$cluster)
cluster

ggplot(old, aes(eruptions, waiting, color=cluster))+
  geom_point(size=4)+
  theme_bw(base_size = 18)

old.k$centers #you wait 54 min, eruption is 2 min -> wait long time, longer eruption

#rotifers example
rot <- adk_data("rotifer")
glimpse(rot)

sum.rot <- rot %>% 
  group_by(PERMANENT_ID, lake.name, date, Family) %>% 
  summarise(orgs=sum(org.l)) %>% 
  glimpse()

rot.spread <- spread(sum.rot, Family, orgs) %>% 
  na.omit() %>% 
  glimpse()

rotifers <- scale(rot.spread[,4:20])

set.seed(88675309)
NbClust(rotifers, method = "kmeans")
#2 is best number of clusters, but not super convincing

k.rot <- kmeans(rotifers, centers = 2)
k.rot
k.rot$tot.wininss
k.rot$cluster

tot_withinss <- map_dbl(1:10, function(k){
  model <- kmeans(x = rotifers, centers = k)
  model$tot.withinss
})

plot(tot_withinss) #as it goes closer to 0, it reaches a point of minimal return
#

fviz_nbclust(rotifers, kmeans, method = "wss") #visualize number of clusters

#gap method
?clusGap
set.seed(123)
gap_stat <- clusGap(rotifers, FUN = kmeans, nstart = 25,
                    K.max = 15, B = 15)
fviz_gap_stat(gap_stat)

#visualize clusters in the main data
a<-ggplot(sum.rot, aes(sum.rot$Family, sum.rot$orgs))+
  geom_boxplot()+
  coord_flip()
a

b<-ggplot(rot.spread, aes(Asplanchnidae, Synchaetidae, color=factor(k.rot$cluster)))+
  geom_point(size=4, alpha=.5)+
  theme(legend.position = "none")
b
grid.arrange(a,b, ncol=2)

GGally::ggpairs(rot.spread[,4:20],
                mapping=aes(color=factor(k.rot$cluster)))
#take it back to original data, where are the clusters in time and space
glimpse(rot.spread)
rot.spread$date2<-ymd(rot.spread$date)
rot.spread$cluster<-factor(k.rot$cluster)

ggplot(rot.spread, aes(date, fill=cluster))+
  geom_bar()+
  facet_wrap(~lake.name)
