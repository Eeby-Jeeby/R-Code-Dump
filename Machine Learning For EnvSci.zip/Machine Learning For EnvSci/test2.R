library(janitor)
library(cluster)
library(tidyverse)
library(lubridate)
library(FactoMineR)
library(factoextra)
library(dendextend)
library(ggthemes)

library(vegan)
library(mclust)
library(tidyverse)
library(GGally)

library(psych)
library(GPArotation)
library(heplots)

library(gridExtra)
library(NbClust)
library(cluster)

library(janitor)
library(tidyverse)
library(lubridate)
library(factoextra)
library(cluster)
library(dendextend)
library(ggthemes)

m <- read.csv("mohonk.csv") %>% 
  na.omit() %>% glimpse()

m$Sample_Date <- mdy(m$Sample_Date) %>% glimpse()

m_group <- m %>% 
  group_by(Location, Sample_Date) %>% 
  glimpse()



ggplot(m_group, aes(Sample_Date, Live_n, colour = Species))+
  geom_point()+
  facet_wrap(~Location)

ggplot(m_group, aes(Location, Live_n, colour = Species))+
  geom_point(size=4)


m.wide <- m %>% 
  spread(Species, Live_n) %>% glimpse()

m.wide.2 <- m.wide %>% 
  group_by(Location) %>% 
  replace(is.na(.), 0) %>% glimpse()

m.wide.2 <- m.wide.2 %>% select(-JEBL)


m.cor <- cor(m.wide.2[,3:10])




corrplot(cor(m.wide.2[,3:10]),
         method = "ellipse",
         type = "lower")

ggpairs(m.wide.2)

#bartlet test-compare correlation matrix to non correlated data
cortest.bartlett(m.cor, n=600)

KMO(m.cor)

eigen(m.cor)

scree(m.cor)
fa.parallel(m.cor, n.obs = 600)

vss(m.cor, n = 600)

#ATTEMPT WITH FAMD
m.wide.3 <- m.wide.2 %>% 
  select(-Sample_Date)

m.famd <- FAMD(m.wide.3)

fviz_screeplot(m.famd)

fviz_famd_var(m.famd, "quali.var",
              repel = TRUE, col.var = "black")

fviz_famd_ind(m.famd, label = "none")

fviz_famd_var(m.famd, "quanti.var", col.var = "black")


m.scale <- scale(m.wide.2[,3:10])
set.seed(100)
NbClust(m.scale, method = "kmeans")

m.k <- kmeans(m.scale, centers = 3) #majority says 2
m.k
m.k$tot.withinss
m.k$cluster
m.k$size

tot_withinss <- map_dbl(1:100, function(k){
  model <- kmeans(x = m.scale, centers = k)
  model$tot.withinss
})

plot(tot_withinss)

fviz_nbclust(m.scale, kmeans, method = "wss") #visualize number of clusters

#visualize clusters in the main data
a<-ggplot(m, aes(m$Species, m$Live_n))+
  geom_boxplot()+
  coord_flip()
a

b<-ggplot(m.wide.2, aes(WOFR, NEWT, color=factor(m.k$cluster)))+
  geom_point(size=4, alpha=.5)+
  theme(legend.position = "none")
b
grid.arrange(a,b, ncol=2)

GGally::ggpairs(m.wide.2[,3:10],
                mapping=aes(color=factor(m.k$cluster)))
#take it back to original data, where are the clusters in time and space
glimpse(m.wide.2)
m.wide.2$cluster<-factor(m.k$cluster)

ggplot(m.wide.2, aes(Sample_Date, fill=cluster))+
  geom_bar()+
  facet_wrap(~Location)

ggplot(m.wide.2, aes(Sample_Date, fill=cluster))+
  geom_bar()

ggplot(m.wide.2, aes(Location, fill=cluster))+
  geom_bar()

#hierarchal for further exploration
m.dist <- dist(m.scale)
m.clust <- hclust(m.dist, method = "ward.D2")

m.dend <- as.dendrogram(m.clust)
m.color <- color_branches(m.dend, h = 10)
plot(m.color)

m.clusters <- cutree(m.clust, k = 5)
#m.use <- m.wide.2[,3:10]
m.wide.2$clusters <- factor(m.clusters)
table(m.wide.2$Location, m.wide.2$clusters)

ggplot(m.wide.2, aes(Location, fill = clusters)) +
  geom_bar() +
  facet_grid(Location ~ month(Sample_Date)) +
  theme_fivethirtyeight()
