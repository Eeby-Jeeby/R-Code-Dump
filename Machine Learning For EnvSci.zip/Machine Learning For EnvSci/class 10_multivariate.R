library(tidyverse)
library(adklakedata)
#install.packages("corrplot")
library(corrplot)
#install.packages("lattice")
library(lattice)
#install.packages("GGally")
#install.packages("scatterplot3d")
#install.packages("mvtnorm")
#install.packages("MVN")
library(GGally)
library(scatterplot3d)
library(mvtnorm)
library(MVN)

chem<-adk_data("chem")
glimpse(chem)
str(chem)

#column means---
chem.list<- by(data = chem[,7:10],
               INDICES = chem$lake.name,
               FUN = colMeans,
               na.rm=T)

chem.list$Brooktrout #now it is a list



#another way
chem.x <- aggregate(SO4_minus2~lake.name, data = chem, FUN = mean)#balling sulfate up by lake, in chem, get the mean
chem.x
#you can just use select and group by, but this works as a backup
tidy <- chem %>% 
  group_by(lake.name) %>% 
  summarise(nitrate = mean(NO3_minus))

var.m <- var(chem[,7:10], na.rm = T)#give covariance
var.m

#correlation matrix
chem_na <- na.omit(chem) #remove na cells
cor(chem_na[,7:10])

corrplot(cor(chem_na[,4:8]),
         method = "ellipse",
         type = "lower")

#pairs graph
pairs(chem_na[,4:8])


dev.off()#VERY HELPFUL WITH CLEARING EVERYTHING TO GET THINGS TO WORK

#lattice version - scatter plot matrix
splom(chem_na[,4:8])

#ggplot version
ggpairs(chem_na, columns = c(4:8))


mvn(chem_na[,4:8])
#not multivariate or univariate

scatterplot3d(chem_na[, c(7, 8, 9)],
              #color = as.numeric(chem_na$lake.name),
              angle=100)

#randomly sample 100 samples from chem with seed set to 7
set.seed(7)
chem.sample <- sample_n(chem_na, 100)
glimpse(chem.sample)
