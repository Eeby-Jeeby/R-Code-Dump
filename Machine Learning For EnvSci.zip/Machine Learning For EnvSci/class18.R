library(janitor)
library(cluster)
library(tidyverse)
library(lubridate)
library(FactoMineR)
library(factoextra)
library(dendextend)
library(ggthemes)

library(vegan)
library(mclust)
library(palmerpenguins)

peng <- penguins %>% 
  na.omit() %>% 
  glimpse()

#select numeric columns
peng.select <- peng %>% 
  select(bill_length_mm,
         bill_depth_mm,
         flipper_length_mm,
         body_mass_g)

#do kmeans
k.peng <- kmeans(peng.select, centers = 3)

#kmeans and species?
table(k.peng$cluster, peng$species)

ggplot(peng, aes(species, bill_depth_mm, color = factor(k.peng$cluster)))+
  geom_point()

#there is more than just bill depth being used for the clusters
#pca again
peng.PCA <- PCA(peng.select)

fviz_pca_var(peng.PCA, label="var")
fviz_pca_ind(peng.PCA, label="none")
#two large clusters?

peng.PCA$ind$coord

peng.hcpc <- HCPC(peng.PCA, nb.clust=3)
HCPC(peng.PCA)

fviz_cluster(peng.hcpc, axes = c(1,2))

#hcpc and species
table(peng.hcpc$data.clust$clust, peng$species)

peng.famd <- FAMD(peng, graph=F)
fviz_famd_var(peng.famd)
fviz_famd_ind(peng.famd)

#cluster on famd
peng.famd.clust <- HCPC(peng.famd, nb.clust=10)
fviz_cluster(peng.famd.clust)
table(peng.famd.clust$data.clust$clust, peng$species)

#mclust
peng.m <- Mclust(peng.select)
summary(peng.m)

fviz_mclust(peng.m, "BIC")
fviz_mclust(peng.m, "classification")
fviz_mclust(peng.m, "uncertainty")

library(dbscan)
data("multishapes")
df <- multishapes[,1:2]
set.seed(123)
km.res <- kmeans(df, 5, nstart = 25)
fviz_cluster(km.res, df, frame = FALSE, geom = "point")

db <- fpc::dbscan(df, eps = 0.05, MinPts = 5)
#plot DBSCAN results
plot(db, df, main = "DBSCAN", frame = FALSE)
db$cluster
?dbscan

#######################

peng.db <- dbscan(peng.PCA$ind$coord, eps = 1)
peng.build <- data.frame(peng.PCA$ind$coord, dbclust=factor(peng.db$cluster)) %>% 
  glimpse()

ggplot(peng.build, aes(Dim.1, Dim.2, colour=db$clust))+
  geom_point()
