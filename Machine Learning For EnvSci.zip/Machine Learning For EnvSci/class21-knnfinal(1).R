#load in libraries
library(tidyverse)
library(class)
library(caTools)
library(janitor)


#get our data
mush <- read_csv("mush.csv") %>% 
  clean_names() %>% 
  na.omit() %>% 
  glimpse()

#remove the first column
mush <- mush %>% 
  select(-x1, -veil_type)
#move class to the first column
mush.new <- mush %>% 
  select(class, everything()) %>% 
  glimpse()

#split the data into testing (30%) and training (70%)
set.seed(12345)
split <- sample.split(mush.new$class, SplitRatio = 0.7)
mush.train <- subset(mush.new, split == "TRUE")
mush.test <- subset(mush.new, split == "FALSE")

#scaling data
mush.train.scale <- scale(mush.train[,2:8])
mush.test.scale <- scale(mush.test[,2:8])

#fitting knn
mush.knn <- knn(train = mush.train.scale,
                test = mush.test.scale, 
                cl = mush.train$class,
                k = 1,
                prob = T)

#isolate probability
mush.prob <- attr(mush.knn, "prob")
head(mush.prob)
#confusion matrix
table(mush.test$class, mush.knn)
#test different k values and see how confusion matrix changes

#can calculate accuracy for each k
#accuracy = 1 - error
error <- mean(mush.knn != mush.test$class)
1 - error

#plot accuracy for different k values
k.values <- c(1, 3, 6, 9, 12, 24)
accuracy.values <- sapply(k.values, function(k) {
  mush.knn.varied <- knn(train = mush.train.scale,
                         test = mush.test.scale,
                         cl = mush.train$class,
                         k = k)
  1 - mean(mush.knn.varied != mush.test$class)
})

#data frame based off calculated accuracy values in order to plot

accuracy <- data.frame(k = k.values, accuracy = accuracy.values)
#and plot
ggplot(accuracy, aes(k, accuracy)) +
  geom_point(color = "orchid") +
  geom_smooth(color = "orchid4")

#just numerical data-----
mush.numerical <- mush.new %>% 
  select(class, cap_diameter, stem_height, stem_width)

split.num <- sample.split(mush.numerical$class, SplitRatio = 0.7)
mush.num.train <- subset(mush.numerical, split == "TRUE")
mush.num.test <- subset(mush.numerical, split == "FALSE")

#scaling data
mushnum.train.scale <- scale(mush.num.train[,2:4])
mushnum.test.scale <- scale(mush.num.test[,2:4])

mush.num.knn <- knn(train = mushnum.train.scale,
                test = mushnum.test.scale, 
                cl = mush.num.train$class,
                k = 1)
accuracy.values <- sapply(k.values, function(k) {
  mushnum.knn.varied <- knn(train = mushnum.train.scale,
                         test = mushnum.test.scale,
                         cl = mush.num.train$class,
                         k = k)
  1 - mean(mushnum.knn.varied != mush.num.test$class)
})

#knn regression
library(caret)
mush.new$class <- ifelse(mush.new$class == 1, "p", "e")

#lets try to predict cap diameter
#basic regression model

model = knnreg(cap_diameter ~ ., data = mush.new)
model

#lets do regression in a more complicated way
set.seed(12345)


model <- train(
  cap_diameter ~ .,
  data = mush.new,
  method = 'knn'
)
model
plot(model)

#preprocessing
model2 <- train(
  medv ~ .,
  data = Boston,
  method = 'knn',
  preProcess = c("center", "scale")
)
model2

