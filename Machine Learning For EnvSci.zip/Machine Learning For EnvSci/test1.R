library(tidyverse)
library(lubridate)
library(stringr)

adcp <- read_csv("adcp backscatter.csv")
jp <- read_csv("JP_WX_001_ALL-Variables_2017-09-04_2017-09-06.csv", skip=10)
adcp$time <- mdy_hm(adcp$time)
#adcp$avg_time <- round_date(adcp$time, unit = "hour")

adcp_2 <- adcp %>% select(ends_with("27"), ends_with("28"), ends_with("29"), ends_with("30"))

adcp_long <- adcp %>% 
  select(!names(adcp_2)) %>% 
  gather(bins, water_flow, -time) %>% 
  glimpse()

adcp_mean <- adcp_long %>% 
  group_by(bins, time) %>% 
  summarize(mean_flow = mean(water_flow)) %>% 
  glimpse()

adcp_mean2 <- adcp_mean %>% 
  separate(bins, c("Beam", "Sample_Number", "Bin", "Bin_Number"), 
           sep = "\\ ", extra = "merge") %>% 
  glimpse()

adcp_mean2$Sample_Number <- as.integer(adcp_mean2$Sample_Number)
adcp_mean2$Bin_Number <- as.integer(adcp_mean2$Bin_Number)
glimpse(adcp_mean2)

adcp_mean2 <- adcp_mean2 %>% 
  select(-Beam, -Bin) %>% 
  glimpse()

jp2 <- jp %>% 
  unite("time",`MM/dd/yyyy`:`HH:mm:ss`, remove = TRUE, sep = "\ ") %>% 
  glimpse()
jp2$time <- mdy_hms(jp2$time)
glimpse(jp2)



adcp_mean3 <- adcp_mean2 %>% 
  group_by(time) %>% 
  mutate(overall_mean = mean(mean_flow))

ggplot(adcp_mean3, aes(time, overall_mean))+
  geom_point(color="darkseagreen")+
  ggtitle("Average Movement Over Time")+
  ylab("Average Backscatter Values")+
  xlab("Time")+
  theme_classic()

adcp_weather <- merge(x = adcp_mean3, y = jp2, by.x = "time", by.y = "time")
glimpse(adcp_weather)

adcp_weather2 <- adcp_weather %>% 
  group_by(time) %>% 
  mutate(avg_air_temp = mean(`Temperature Air HC2 (C)`),
         avg_windspeed = mean(`WindSpeed Air RMY85006 (m/s)`),
         #avg_precip = mean(`Precipitation-Rain Air TB3 (mm)`),
         #avg_pressure = mean(`BarometricPressure Air HC2 (hPa)`),
         avg_humidity = mean(`RelativeHumidity Air HC2 (Percent)`))


ggplot(adcp_weather2, aes(avg_windspeed, overall_mean, color = Bin_Number))+
  geom_point()+
  ggtitle("Average Windspeed vs Average Backscatter Values")+
  ylab("Average Backscatter Values")+
  xlab("Average Windspeed (m/s)")+
  theme_classic()

ggplot(adcp_weather2, aes(avg_air_temp, overall_mean, color = Bin_Number))+
  geom_point()+
  ggtitle("Average Air Temp vs Average Backscatter Values")+
  ylab("Average Backscatter Values")+
  xlab("Average Air Temp (C)")+
  theme_classic()

#ggplot(adcp_weather2, aes(time, overall_mean, color = avg_pressure))+
 # geom_point()+
#  ggtitle("Average Air Temp vs Average Backscatter Values")+
 # ylab("Average Backscatter Values")+
#  xlab("Time")+
#  theme_classic()

ggplot(adcp_weather2, aes(avg_humidity, overall_mean, color = Bin_Number))+
  geom_point()+
  ggtitle("Average Humidity vs Average Backscatter Values")+
  ylab("Average Backscatter Values")+
  xlab("Average Humidity (%)")+
  theme_classic()

  
