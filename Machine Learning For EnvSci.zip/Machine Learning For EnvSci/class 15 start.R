library(broom)

library(tidyverse)
library(lubridate)
library(FactoMineR)
library(adklakedata)
library(factoextra)


chem<-adk_data('chem')
chem$date<-ymd(chem$date)
# 
chem.gather <- gather(chem, "analyte", "value",
                      -PERMANENT_ID,
                      -date,
                      -month,
                      -lake.name) %>% 
  glimpse()

#how has DOC changed over time
doc <- chem.gather %>% 
  filter(analyte == "DOC")

#calculate the change
lm.doc <- lm(value~date, data=doc)
summary(lm.doc)
ggplot(doc, aes(date, value))+
  geom_point()+
  geom_smooth(method = "lm")

tidy(lm.doc)#takes information for lm.doc and puts it in table
glance(lm.doc)#gives you more info

fit.doc <- augment(lm.doc)#build the linear model
fit.doc

ggplot(fit.doc, aes(date, value))+
  geom_point()+
  geom_line(aes(date, .fitted,color = "red"))

#this linear model isnt very good, lets plot the change per lake
ggplot(doc, aes(date, value))+
  geom_point()+
  geom_smooth(method = "lm", color = "red",size = 2)+
  facet_wrap(~lake.name, scales = "free")+
  theme_bw()

#plot all analytes (at your own risk!!!)
#ggplot(doc, aes(date, value))+
#  geom_point(size = 0.2)+
#  geom_smooth(method = "lm", color = "red")+
#  facet_wrap(analyte)+
#  theme_bw()

#interesting.lakes <- c("Queer", "Dart", "Raquette", "Willis")

chem2 <- chem #%>% 
  #filter(lake.name %in% interesting.lakes)

glimpse(chem2)

#folder within a dataframe, with the data in the folder basically?
lake_nested <- chem2 %>% 
  group_by(lake.name) %>% 
  nest()

lake_nested$data

#apply model for each listed item
lake_models <- lake_nested %>% 
  mutate(pH = map(data, ~lm(pH ~ date, data=.x)),
         so4 = map(data, ~lm(SO4_minus2 ~ date, data=.x)),
         no3 = map(data, ~lm(NO3_minus ~ date, data=.x)),
         cl = map(data, ~lm(CL ~ date, data=.x)),
         doc = map(data, ~lm(DOC ~ date, data=.x)),
         ca = map(data, ~lm(Calcium ~ date, data=.x)),
         anc = map(data, ~lm(ANC.ueq.L ~ date, data=.x)))

lake_models$pH

#access model data
ph.slopes <- lake_models %>% 
  mutate(slope = map(pH, ~tidy(.x))) %>% 
  unnest(slope)

#start building new dataset of slopes by acessing data and binding it to a new dataframe
analysis <- data.frame(lake = ph.slopes$lake.name)
analysis$term <- ph.slopes$term
analysis$pH <- ph.slopes$estimate

glimpse(analysis)

so4.slopes <- lake_models %>% 
  mutate(slope = map(so4, ~tidy(.x))) %>% 
  unnest(slope)
analysis$so4 <- so4.slopes$estimate

no3.slopes <- lake_models %>% 
  mutate(slope = map(no3, ~tidy(.x))) %>% 
  unnest(slope)
analysis$no3 <- no3.slopes$estimate

cl.slopes <- lake_models %>% 
  mutate(slope = map(cl, ~tidy(.x))) %>% 
  unnest(slope)
analysis$cl <- cl.slopes$estimate

doc.slopes <- lake_models %>% 
  mutate(slope = map(doc, ~tidy(.x))) %>% 
  unnest(slope)
analysis$doc <- doc.slopes$estimate

ca.slopes <- lake_models %>% 
  mutate(slope = map(ca, ~tidy(.x))) %>% 
  unnest(slope)
analysis$ca <- ca.slopes$estimate

anc.slopes <- lake_models %>% 
  mutate(slope = map(anc, ~tidy(.x))) %>% 
  unnest(slope)
analysis$anc <- anc.slopes$estimate

glimpse(analysis)

pca.analysis <- analysis %>% 
  filter(term == "date") %>% 
  column_to_rownames(var = "lake") %>% 
  glimpse()

corrplot::corrplot(cor(pca.analysis[,2:8]))

pca.plot <- PCA(pca.analysis[,2:8], scale=T)

fviz_pca_ind(pca.plot)
#install.packages("Factoshiny")
library(Factoshiny)

PCAshiny(pca.analysis)

