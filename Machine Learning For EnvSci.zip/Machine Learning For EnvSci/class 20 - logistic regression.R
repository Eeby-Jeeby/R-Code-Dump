library(janitor)
library(tidyverse)

#install.packages("DescTools")
library(DescTools)
library(car)
library(ggthemes)

#reading in the csvs
temp <- read_csv("Bemus2023.csv") %>% 
  clean_names() %>% 
  glimpse()

weather <- read_csv("weather(2).csv") %>% 
  glimpse()

#merge into one DF
combined <- merge(weather, temp, by.x = "valid", by.y = "datetime")
glimpse(combined)

#fixing names
combined <- combined %>% 
  rename(datetime = valid)

#Calculating parameters for stratification
diff <- combined %>% 
  select(wtr_3_0, wtr_6_0)

diff$ratio <- (diff$wtr_3_0 - diff$wtr_6_0)/3
diff$strat <- ifelse(diff$ratio >= 1, 1, 0)
combined$strat <- diff$strat

#Representation over time
ggplot(combined, aes(datetime, strat)) +
  geom_point() +
  theme_bw()

#creating a sample
glimpse(combined)
set.seed(100)

train_index <- sample(1:nrow(combined), size = floor(0.6 * nrow(combined)),
                      replace = F) #60 percent of data used for training
training <- combined[train_index, c(1, 3:9, 12)]
testing <- combined[-train_index, c(1, 3:9, 12)]

#making the model (run with combined to demonstrate)
logit_tempGap <- glm(strat ~ tmpc + dew_point + relative_humidity +
                       wind_direction + sknt + atmospheric_pressure + precipitation,
                     data = training, family = binomial)

summary(logit_tempGap)

#strength of model
PseudoR2(logit_tempGap)

#creating the prediction
prediction <- predict(logit_tempGap,
                      testing[2:8], type = "response") #not testing datetime
plot(prediction) #anything above 0.5 we treat as 1, <0.5 we treat as 0 since the odds of stratification match one or the other

#actually predicting
testing$prediction <- prediction

#high probability of strat if >0.5
testing$prediction_binom <- ifelse(prediction >= 0.5, 1, 0)

glimpse(testing)

table(testing$strat, testing$prediction_binom)

#geom jitter vs point for data visualization
#red is not stratified, blue is stratified
ggplot(testing, aes(datetime, prediction_binom, color = factor(strat)))+
  geom_point()+
  #geom_jitter(width = 0.2, height = 0.1)+
  xlab("Dates")+
  ylab("Binomial Prediction")+
  ggtitle("Date vs Binomial Prediction")+
  labs(color = "Obs Strat")+
  theme_economist_white()
#difficult to look at
ggplot(testing, aes(datetime, prediction_binom, color = factor(strat)))+
  #geom_point()+
  geom_jitter(width = 0.2, height = 0.1, alpha = 0.25)+
  xlab("Dates")+
  ylab("Binomial Prediction")+
  ggtitle("Date vs Binomial Prediction")+
  labs(color = "Obs Strat")+
  theme_economist_white()
#geom jitter adds variance to points, which moves it away from the line,
#makes it eaiser to look at i guess

#importance of each coefficient -> we saw before there were some significant variables
logit_tempGap$coefficients

df <- data.frame("vals" = abs(logit_tempGap$coefficients[-1])) 

df <- tibble::rownames_to_column(df, "Coefficient")
glimpse(df)

ggplot(df, aes(Coefficient, vals))+
  geom_col()+
  theme(axis.text.x = element_text(size=8, angle=20))

#if you remove the abs value, we see
df <- data.frame("vals" = (logit_tempGap$coefficients[-1])) 

df <- tibble::rownames_to_column(df, "Coefficient")
glimpse(df)

ggplot(df, aes(Coefficient, vals))+
  geom_col()+
  theme(axis.text.x = element_text(size=8, angle=20))

#regression is not a good tool to look at unbalanced data




#Go into the model and try to remove variables 
#to see if it makes the model better
