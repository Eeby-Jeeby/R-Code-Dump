library(tidyverse)
library(janitor)
library(lubridate)

swamp<-read_csv('beams.csv') %>% 
  clean_names() %>% glimpse()

swamp$sample_time<- mdy_hm(swamp$sample_time, tz="EST")

deployed <- ymd_hm("2019-8-19 14:30", tz="est")

difftime(swamp$sample_time[1], deployed, units = "auto")

diff <- swamp$sample_time[1] - deployed
diff

swamp$fixed.time <- swamp$sample_time - diff
swamp$fixed.time
glimpse(swamp)

times <- swamp$fixed.time
times

elapsed <- times[2] - times[1]
elapsed

difftime(times[2], times[1], units="secs")
elapsed

#say you lose your time stamps, but you know the starting point and how much time elapsed between them
calc.time <- times[1] + (elapsed *0:42) #creating vector field of 43 observations starting from time 1, where there is 6000 secs in between each observation
calc.time
time.check  <- data.frame(calc.time, times)

head(time.check)

time.check2 <- time.check %>% 
  mutate(same = calc.time == times)

head(time.check2)

min.time <- min(times)
max.time <- max(times)
time.int <- max.time %--% min.time
time.int

deploy.interval <- interval(min.time, max.time)
deploy.interval

tz(calc.time[1])
calc.time[1]

with_tz(calc.time[1], tzone = "UTC") #standardized
OlsonNames()

with_tz(calc.time[1], tzone = "NZ")

?force_tz
force_tz(calc.time, tzone = "NZ")

cool_stamp <- stamp("Monday, 9-15-24 10:45")
cool_stamp(times)

deploy.interval
isitin <- mdy_hm("08-20-2019 10:19")
isitin %within% deploy.interval

#################

weather <- read_csv("weather(1).csv") %>% 
  clean_names() %>% 
  glimpse()

weather$date <- mdy_hm(weather$date_time, tz = "EST")
glimpse(weather)
#ceiling_date(weather$date, unit = "10 seconds")
add.seconds <- seconds(10)
min <- min(weather$date)

weather.new <- weather$date[1] + (add.seconds * 0:111793)
weather.new


weather.updated <- cbind(weather.new, weather)
glimpse(weather.updated)

weather.check <- weather.updated %>% 
  mutate(check = weather$date == weather.new)
weather.check

#dont change the data, we cant just add ten seconds to the data, we would have to
#take the average of the measurements instead