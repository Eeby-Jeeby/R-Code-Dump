#variable/columns -> feature space
#observations -> instances
#thing you are trying to predict -> 

#need to install and load
library(MASS) #has a select that will overlay dyplr
library(vegan)
library(Rtsne)

#need to load
library(corrplot)
library(adklakedata)
library(tidyverse)
library(FactoMineR)#need this
library(factoextra)#need this
library(FactoInvestigate)#optional
library(ggfortify)#optional

#T-SNE
chem<-adk_data("chem")
interesting.lakes <- c("Big Moose", "G", "Jockeybush", "Indian")

chem2<- chem %>% 
  filter(year == 2011 & lake.name %in% interesting.lakes) %>% 
  na.omit()

glimpse(chem2)

chem3<-chem2[,c(6:16)]
tsne_output <- Rtsne(chem3, PCA = T, dims = 3, perplexity=2)

head(tsne_output)

tsne_plot <- data.frame(tsne_x = tsne_output$Y[, 1],
                        tsne_y = tsne_output$Y[, 2])

tsne_plot <- cbind(tsne_plot, chem2$lake.name)

ggplot(tsne_plot, aes(tsne_x, tsne_y, colour = `chem2$lake.name`))+
  geom_text(aes(label = `chem2$lake.name`))+
  ggtitle("t-SNE")+
  theme(legend.position = "none")
#randomized, will be different looking

#FA mixed data

cliff <- read.csv("avian_cliff_communities_dataset.csv") %>% glimpse

cliff.use <- cliff[,1:11] #just looking at the first 11 columns to get a sense, no idea what the variable means

cliff.famd <- FAMD(cliff.use)

fviz_screeplot(cliff.famd)

fviz_famd_var(cliff.famd, "quali.var",
              repel = TRUE, col.var = "black")


fviz_famd_ind(cliff.famd, label = "none",
              habillage = "Aspect")

fviz_famd(cliff.famd)

fviz_famd_var(cliff.famd, "quanti.var", col.var = "black")
