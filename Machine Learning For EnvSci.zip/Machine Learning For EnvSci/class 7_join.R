library(data.table)
library(tidyverse)
library(lubridate)
library(janitor)

# copy of previous work
swamp<-read_csv(file ="beams.csv") %>% 
  clean_names()

swamp$sample_time<-mdy_hm(swamp$sample_time)

deployed<- ymd_hm("2019-8-19 14:30")

diff<- swamp$sample_time[1] - deployed

swamp$sample_time <- swamp$sample_time - diff

swamp <- swamp %>% 
  select(sample_time, contains("vel")) %>% 
  gather("beam","velocity", -sample_time) %>% 
  filter(velocity != "#N/A") 

swamp$velocity<- as.numeric(swamp$velocity)

swamp$velocity<- as.numeric(swamp$velocity/4)

# sum velocity
swamp.sum<- swamp%>%  
  group_by(sample_time) %>% 
  summarise(sum_vel= sum(velocity))

glimpse(swamp.sum)

################
#grab weather data and clean the names
weather <- read_csv("weather(1).csv") %>% 
  clean_names()
glimpse(weather)

#change date/time to be not a character
weather$date_time <- mdy_hm(weather$date_time)
glimpse(weather)

#average wind speed and sum of rain for each minute
weather.sum <- weather %>% 
  group_by(date_time) %>% 
  summarise(windspeed = mean(wind_speed_m_s),
            rain = sum(rain_total_mm)) %>% 
  glimpse()

glimpse(swamp.sum)

#let"s inner merge (only info in both gets merged) (the intersection)
inner <- merge(x = swamp.sum,
               y = weather.sum,
               by.x = "sample_time",
               by.y = "date_time")
glimpse(inner)

#left merge
left <- merge(x = swamp.sum,
              y = weather.sum,
              by.x = "sample_time",
              by.y = "date_time",
              all.x = TRUE)
glimpse(left)

# no difference between left and inner merge (all swamp data is kept)

#right join
right <- merge(x = swamp.sum,
              y = weather.sum,
              by.x = "sample_time",
              by.y = "date_time",
              all.y = TRUE)
glimpse(right)

#lots of NAs because we"re missing a lot of data from the dates not matching up

#full merge 
all <- merge(x = swamp.sum,
              y = weather.sum,
              by.x = "sample_time",
              by.y = "date_time",
              all = TRUE)
#same as the right join

#interval
deployed.duration <- interval(min(swamp$sample_time),
                              max(swamp$sample_time))

#filter data for being within the interval
weather2 <- weather %>% 
  filter(date_time %within% deployed.duration)

#make a window of time just before sample was taken, group it by a cut of the time
#then sum and averagee just for those cut groups
weather3 <- weather2 %>% 
  group_by(date_time = cut(date_time, breaks = "100 min")) %>% 
  summarise(rain = sum(rain_total_mm),
            windspeed = mean(wind_speed_m_s)) %>% 
  glimpse()

#now we can merge it!

#they have the same number of observations so it shouldn"t matter which type
glimpse(swamp.sum)
glimpse(weather3)

#need to fix the date so it"s not a factor
weather3$sample_time <- ymd_hms(weather3$date_time)


#NOW we can merge :)
swamp.weather <- merge(swamp.sum,
                       weather3,
                       by = "sample_time")

#let"s plot it for fun
ggplot(swamp.weather, aes(rain, sum_vel)) +
  geom_point()

library(adklakedata)

rotifer <- adk_data("rotifer") %>% 
  glimpse()
chem <- adk_data("chem") %>% 
  glimpse()

#make a key
rotifer2 <- rotifer %>% 
  mutate(key = paste(lake.name, year, month, sep = "-")) %>% 
  group_by(key) %>% 
  filter(org.l > 0.01) %>% 
  count() %>% 
  glimpse()

chem2 <- chem %>% 
  mutate(key = paste(lake.name, year, month, sep = "-"))

class <- merge(rotifer2, chem2, by="key")

ggplot(class, aes(pH, n))+
  geom_point()+
  geom_smooth()+
  facet_wrap(~lake.name, scales = "free")
