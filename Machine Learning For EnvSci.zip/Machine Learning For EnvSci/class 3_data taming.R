#load libraries
library(tidyverse)
library(adklakedata)
library(anytime)
library(skimr)
library(janitor)

#read data
?adk_data
crust <- adk_data("crustacean")
getwd()
setwd("C:/Users/Evelyn/Desktop/Machine Learning For EnvSci")

#write data to csv
write_csv(crust, "crustykrabs.csv")

#read from the csv we just wrote
crust_2 <- read_csv("crustykrabs.csv") %>% glimpse()
crust_3 <- read.csv("crustykrabs.csv") %>% glimpse()

#get an overview of data fields
skim(crust)

glimpse(crust)


#filter for genus daphnia
daphnia <- crust %>% 
  filter(Genus == "Daphnia") %>% 
  glimpse()


#see what species we have in this genus
daphnia %>% distinct(Species)

#see how many of each species we have
daphnia %>% count(Species)

#get an actual idea of how many of each species we have
daphnia %>% 
  filter(org.l > 0) %>% 
  count(Species)

#record average size of each species
daphnia_size_class <- daphnia %>% 
  #filter(org.l > 0) %>% 
  group_by(Species) %>% 
  summarize(avg=mean(ug_WWperind)) %>% 
  glimpse()

#view average
daphnia_size_class

#add a column containing a size descriptor to daphnia frame
daphnia.sizes <- daphnia %>% 
  mutate(size = recode(Species,
                       "pulex" = "large",
                       "dubia" = "medium",
                       "parvula" = "medium",
                       .default = "small"))

table(daphnia.sizes$Species, daphnia.sizes$size)

##Test with ifelse statement to automatically sort sizes##
daphnia.sizes.extra <- daphnia %>% 
  group_by(Species) %>% 
  mutate(size = ifelse(mean(ug_WWperind) >= 70, "large", 
                       ifelse(mean(ug_WWperind) >= 20, "medium", "small")))

glimpse(daphnia.sizes.extra)
###

#check out this new frame we made
glimpse(daphnia.sizes)

#create new version of sizes frame with corrected dates
daphnia.sizes.2 <- daphnia.sizes %>% 
  mutate(newdate = anytime(daphnia.sizes$date))

#examine this new frame
glimpse(daphnia.sizes.2)

#create a size plot
plot(daphnia.sizes.2$newdate, daphnia.sizes.2$org.l)

ggplot(daphnia.sizes.2, aes(newdate, org.l, color = Species))+
  geom_point()+
  xlab("Year")+
  ylab("Number of Daphnia")+
  ggtitle("Count of Daphnia")+
  theme_classic()

##clean up tea island data##

teaisland <- read_csv("teaisland.csv", skip = 18) %>% glimpse()

#get date into right format and remove the original date time
teaisland_corrected <- teaisland %>% 
  mutate(Date = anytime(teaisland$`Date Time`)) %>% 
  select(-c(`Date Time`)) %>% 
  glimpse()

teaisland$surface<-teaisland$`Temperature (°F) (749249)`
glimpse(teaisland)

#select for depth and temperature and give vars better names
teaisland_depthtemp <- teaisland_corrected %>% 
  select(Depth = `Depth (m) (720372)`,
         Temperature = `Temperature (°F) (737866)`) %>% 
  glimpse()

#graph relation between depth and temp
ggplot(teaisland_depthtemp,(aes(Depth, Temperature)))+
  geom_point()
